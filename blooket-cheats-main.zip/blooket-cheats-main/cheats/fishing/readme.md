# Fishing Frenzy

## [Frenzy](frenzy.js)
Causes a frenzy

## [Remove Distraction](removeDistraction.js)
Removes enemy distractions

## [Send Distraction](sendDistraction.js)
Sends a random distraction

## [Set Lure](setLure.js)
Sets fishing lure (from 1-5)

## [Set Weight](setWeight.js)
Sets fishing weight