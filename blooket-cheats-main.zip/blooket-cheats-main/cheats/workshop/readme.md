# Santa's Workshop

## [Remove Distractions](removeDistractions.js)
Removes all enemy distractions

## [Send Distraction](sendDistraction.js)
Sends a random distraction

## [Set Toys](setToys.js)
Sets the amount of toys you have

## [Set Toys Per Q](setToysPerQ.js)
Sets the amount of toys you get per question

## [Swap Toys](swapToys.js)
Swaps toys with someone