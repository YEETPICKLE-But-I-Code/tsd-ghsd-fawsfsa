# Crypto Hack

## [Always Triple](alwaysTriple.js)
Always get triple crypto

## [Auto Guess](autoGuess.js)
Selects the correct password when hacking

## [Choice ESP](choiceESP.js)
Shows what's behind the choice boxes

## [Password ESP](passwordESP.js)
Highlights the correct password

## [Remove Hack](removeHack.js)
Removes an attacking hack

## [Set Crypto](setCrypto.js)
Sets crypto

## [Set Password](setPassword.js)
Sets hacking password

## [Steal Players Crypto](stealPlayersCrypto.js)
Steals all of someone's crypto