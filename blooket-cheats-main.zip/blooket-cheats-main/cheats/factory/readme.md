# Factory

## [Choose Blook](chooseBlook.js)
Gives you a blook

## [Free Upgrades](freeUpgrades.js)
Sets upgrade prices to 0 for all current blooks

## [Max Blooks](maxBlooks.js)
Sets all your blooks' levels to 5

## [Remove Glitches](removeGlitches.js)
Removes all enemy glitches

## [Send Glitch](sendGlitch.js)
Sends a random glitch

## [Set All Mega Bot](setAllMegaBot.js)
Sets all your blooks to level 5 Mega Bots

## [Set Cash](setCash.js)
Sets the amount of cash you have