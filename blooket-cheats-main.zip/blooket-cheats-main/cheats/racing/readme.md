# Racing

## [Instant Win](instantWin.js)
Instantly wins the race

## [Set Questions](setQuestions.js)
Sets the amount of questions you have left to answer