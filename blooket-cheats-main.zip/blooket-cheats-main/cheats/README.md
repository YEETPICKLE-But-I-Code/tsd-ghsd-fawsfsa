# Cheats

## [Gui](gui.js)
A GUI containing every cheat in a menu

## [Mobile Gui](mobileGui.js)
The first GUI, basic UI reportedly good on mobile[^1]

## [React Gui](reactGui.js)
A GUI written in React made to get around Blooket's anti-cheat

## [K Gui](KGui.js)
A new GUI with several new features and design changes

### [Brawl](brawl)

### [Cafe](cafe)

### [Crypto](crypto)

### [Dinos](dinos)

### [Doom](doom)

### [Factory](factory)

### [Fishing](fishing)

### [Flappy](flappy)

### [Global](global)

### [Gold](gold)

### [Kingdom](kingdom)

### [Racing](racing)

### [Royale](royale)

### [Rush](rush)

### [Tower-defense](tower-defense)

### [Tower-defense-2](tower-defense-2)

### [Voyage](voyage)

### [Workshop](workshop)

[^1] Not actually designed for mobile