# Gold Quest

## [Always Triple](alwaysTriple.js)
Always get triple gold

## [Auto Choose](autoChoose.js)
Automatically chooses the best chest to maximize gold

## [Auto Choose Once](autoChooseOnce.js)
Chooses the best chest to maximize gold

## [Chest ESP](chestESP.js)
Shows what each chest will give you

## [Reset Players Gold](resetPlayersGold.js)
Sets a player's gold to 0

## [Set Gold](setGold.js)
Sets current gold

## [Set Players Gold](setPlayersGold.js)
Sets another player's gold

## [Swap Gold](swapGold.js)
Swaps gold with another player

## [Remove Bad Choices](removeBadChoices.js)
Removes the chance of getting Lose 25%, Lose 50%, and Nothing