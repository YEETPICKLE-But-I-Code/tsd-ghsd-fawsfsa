# Battle Royale Intervals

## [Auto Answer](autoAnswer.js)
Automatically chooses the correct answer