# Battle Royale

## [Auto Answer](autoAnswer.js)
Chooses the correct answer

### [Intervals](intervals)