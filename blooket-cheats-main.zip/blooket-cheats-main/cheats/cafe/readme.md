# Cafe

## [Max Items](maxItems.js)
Maxes out items in the shop[^1]

## [Remove Customers](removeCustomers.js)
Skips the current customers[^2]

## [Reset Abilities](resetAbilities.js)
Resets the used abilities in the shop[^1]

## [Set Cash](setCash.js)
Sets cafe cash

## [Stock Food](stockFood.js)
Stocks all food to 99[^2]

[^1] Only usable in the shop
[^2] Not usable in the shop