# Tower Defense 2

## [Max Towers](maxTowers.js)
Makes all of your towers OP

## [Remove Enemies](removeEnemies.js)
Kills all the enemies

## [Set Coins](setCoins.js)
Sets the amount of coins you have

## [Set Health](setHealth.js)
Sets the amount of health you have

## [Set Round](setRound.js)
Sets the current round