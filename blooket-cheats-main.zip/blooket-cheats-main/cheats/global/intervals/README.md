# Global Intervals

## [Auto Answer](autoAnswer.js)
Automatically answers questions for you

## [Highlight Answers](highlightAnswers.js)
Automatically highlights correct answers in green and incorrect in red

## [Percent Auto Answer](percentAutoAnswer.js)
Answers questions correctly or incorrectly depending on the input grade goal

## [Subtle Highlight Answers](subtleHighlightAnswers.js)
Automatically removes the shadow from correct answer