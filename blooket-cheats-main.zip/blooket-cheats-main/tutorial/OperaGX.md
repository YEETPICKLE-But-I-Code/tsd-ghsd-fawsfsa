# 1. Navigate to `cheats` folder
![Opera GX part 1](/tutorial/operagx/part%20(1).png)
# 2. Open `Bookmarklets.html` file
![Opera GX part 2](/tutorial/operagx/part%20(2).png)
# 3. Click `Download raw file`
![Opera GX part 3](/tutorial/operagx/part%20(3).png)
# 4. Right click bookmarks bar > Bookmarks
![Opera GX part 4](/tutorial/operagx/part%20(4).png)
# 5. Click Import/Export > Import bookmarks
![Opera GX part 5](/tutorial/operagx/part%20(5).png)
# 6. Switch to `Bookmarks HTML file`
![Opera GX part 6](/tutorial/operagx/part%20(6).png)
# 7. Choose saved file from step 3
![Opera GX part 7](/tutorial/operagx/part%20(7).png)
# 8. Happy cheating
![Opera GX part 8](/tutorial/operagx/part%20(8).png)